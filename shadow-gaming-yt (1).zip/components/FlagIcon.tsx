
import React from 'react';

interface FlagIconProps {
  code: string;
  size?: number;
}

const FlagIcon: React.FC<FlagIconProps> = ({ code, size = 32 }) => {
  const codeMap: Record<string, string> = {
    'EU': 'eu',
    'US': 'us',
    'NZ': 'nz',
    'CA': 'ca',
    'AR': 'ar',
    'AU': 'au',
    'MX': 'mx',
    'JP': 'jp',
    'BR': 'br',
    'GB': 'gb',
    'TR': 'tr',
    'CH': 'ch',
    'SG': 'sg',
    'BD': 'bd',
    'NG': 'ng',
    'ID': 'id',
    'PH': 'ph',
    'PK': 'pk',
    'DZ': 'dz',
    'CO': 'co',
    'ZA': 'za',
    'IN': 'in',
  };

  const iso = codeMap[code] || code.toLowerCase();
  
  return (
    <div 
      className="rounded-full overflow-hidden border border-gray-600 shadow-sm"
      style={{ width: size, height: size }}
    >
      <img 
        src={`https://flagcdn.com/w80/${iso}.png`} 
        alt={code}
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default FlagIcon;
