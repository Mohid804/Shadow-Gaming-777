
import React from 'react';

const LoadingDots: React.FC = () => {
  return (
    <div className="flex space-x-2 justify-center items-center">
      <div className="w-6 h-6 bg-red-600 rounded-full animate-pulse"></div>
      <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse delay-75"></div>
      <div className="w-2 h-2 bg-white rounded-full animate-pulse delay-150"></div>
    </div>
  );
};

export default LoadingDots;
