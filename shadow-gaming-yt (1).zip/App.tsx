
import React, { useState, useEffect } from 'react';
import { AppScreen, CurrencyPair, AnalysisResult } from './types';
import { CURRENCY_PAIRS, QUOTEX_LINK, DASHBOARD_LINK } from './constants';
import FlagIcon from './components/FlagIcon';
import LoadingDots from './components/LoadingDots';
import { getMarketAnalysis } from './services/geminiService';
import { LineChart, Line, ResponsiveContainer, YAxis } from 'recharts';

const BOT_NAME = "SHADOW GAMING YT";

// --- Splash Screen Component ---
const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(() => onComplete(), 2500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="h-screen w-full bg-gradient-to-b from-[#1a1a1a] to-[#000] flex flex-col items-center justify-center p-8 text-center">
      <div className="relative mb-12 animate-pulse">
         <div className="w-48 h-48 bg-red-600/10 rounded-full flex items-center justify-center backdrop-blur-md border border-red-600/20">
            <svg width="120" height="120" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L4.5 20.29L5.21 21L12 18L18.79 21L19.5 20.29L12 2Z" fill="#dc2626"/>
            </svg>
         </div>
      </div>

      <h1 className="text-4xl font-bold mb-4 tracking-tighter text-white uppercase italic">{BOT_NAME}</h1>
      
      <div className="mt-8">
        <LoadingDots />
      </div>

      <p className="mt-12 text-red-600 text-xl font-black tracking-widest">SOFYAN TRADER</p>
    </div>
  );
};

// --- Password Gate Component ---
const PasswordScreen: React.FC<{ onUnlock: () => void }> = ({ onUnlock }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === '@777') {
      onUnlock();
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="h-screen w-full bg-[#000] flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-sm space-y-8 bg-[#111] p-8 rounded-3xl border border-white/5 shadow-2xl">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-600/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-600/30">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
          </div>
          <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Access Locked</h2>
          <p className="text-gray-500 text-sm mt-1">Enter your authorization code</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="ENTER PASSWORD"
            className={`w-full bg-black border ${error ? 'border-red-600' : 'border-white/10'} text-white text-center py-4 rounded-xl focus:outline-none focus:border-red-600 transition-all font-black text-xl tracking-widest placeholder:text-gray-700`}
            autoFocus
          />
          {error && <p className="text-red-600 text-[10px] text-center font-bold uppercase tracking-widest">Access Denied: Invalid Key</p>}
          <button 
            type="submit"
            className="w-full py-4 bg-red-600 text-white font-black rounded-xl hover:bg-red-700 transition-all shadow-lg active:scale-95 uppercase tracking-widest"
          >
            Unlock Bot
          </button>
        </form>
        
        <p className="text-[10px] text-gray-600 text-center uppercase tracking-widest leading-relaxed">
          Proprietary Intelligence Engine<br/>Unauthorized access is prohibited
        </p>
      </div>
    </div>
  );
};

// --- Pair List Component ---
const PairList: React.FC<{ onSelect: (pair: CurrencyPair) => void }> = ({ onSelect }) => {
  return (
    <div className="min-h-screen bg-[#000] p-4 flex flex-col pt-12">
      <h1 className="text-3xl font-black text-center mb-1 text-white italic tracking-tighter uppercase">{BOT_NAME}</h1>
      <p className="text-gray-500 text-center mb-8 uppercase text-[10px] tracking-[0.3em] font-bold">Live OTC Terminal</p>

      <div className="flex-1 overflow-y-auto space-y-3 pb-8">
        {CURRENCY_PAIRS.map((pair) => (
          <button
            key={pair.id}
            onClick={() => onSelect(pair)}
            className="w-full bg-[#111] hover:bg-[#1a1a1a] border border-white/5 transition-colors rounded-2xl p-4 flex items-center justify-between group"
          >
            <div className="flex items-center space-x-4">
              <span className="text-red-600/50 group-hover:text-red-600">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
              </span>
              <div className="flex -space-x-2">
                <FlagIcon code={pair.flag1} size={36} />
                <FlagIcon code={pair.flag2} size={36} />
              </div>
              <span className="text-lg font-bold tracking-tight text-white">{pair.name}</span>
            </div>
            <div className="text-gray-800 group-hover:text-red-600 transition-colors">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </div>
          </button>
        ))}

        <div className="pt-6 pb-4">
          <a 
            href={QUOTEX_LINK} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block w-full text-center py-4 bg-red-600 text-white font-black rounded-2xl hover:bg-red-700 transition-all shadow-lg active:scale-95 uppercase tracking-widest"
          >
            OPEN QUOTEX ACCOUNT
          </a>
          <p className="text-[10px] text-gray-500 mt-3 text-center uppercase tracking-[0.2em] font-bold">Official Partner Link</p>
        </div>
      </div>
    </div>
  );
};

// --- Analysis Screen Component ---
const AnalysisScreen: React.FC<{ pair: CurrencyPair; onBack: () => void }> = ({ pair, onBack }) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [hasRegistered, setHasRegistered] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [mockData, setMockData] = useState<{ value: number }[]>([]);

  useEffect(() => {
    const data = Array.from({ length: 20 }, (_, i) => ({
      value: 1.05 + Math.random() * 0.1
    }));
    setMockData(data);
  }, [pair]);

  const startAnalysis = async () => {
    setAnalyzing(true);
    try {
      const res = await getMarketAnalysis(pair.name);
      setTimeout(() => {
        setResult(res);
        setAnalyzing(false);
      }, 3000);
    } catch (error) {
      console.error(error);
      setAnalyzing(false);
    }
  };

  const handleRegisterClick = () => {
    window.open(QUOTEX_LINK, '_blank');
    setHasRegistered(true);
  };

  return (
    <div className="min-h-screen bg-[#000] flex flex-col text-white">
      <header className="p-4 flex items-center justify-between border-b border-white/5 bg-black/50 backdrop-blur-md sticky top-0 z-10">
        <button onClick={onBack} className="p-2 bg-white/5 rounded-full active:scale-90 transition-transform">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
        </button>
        <h1 className="text-xl font-black uppercase tracking-tighter italic">{pair.name}</h1>
        <div className="w-10"></div>
      </header>

      <main className="flex-1 p-6 flex flex-col overflow-y-auto pb-12">
        <div className="bg-[#111] rounded-3xl p-6 border border-white/5 shadow-2xl min-h-[450px] flex flex-col relative overflow-hidden">
          {analyzing ? (
            <div className="flex-1 flex flex-col items-center justify-center space-y-6 py-20">
              <div className="relative">
                <div className="w-20 h-20 border-4 border-red-600/10 rounded-full"></div>
                <div className="absolute top-0 left-0 w-20 h-20 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
              <div className="text-center space-y-2">
                <p className="text-red-600 font-black animate-pulse text-xl tracking-tighter uppercase italic">SHADOW AI SCANNING...</p>
                <p className="text-gray-500 text-[10px] uppercase tracking-widest font-bold">Analyzing Live Flux Vectors</p>
              </div>
            </div>
          ) : !hasRegistered ? (
            <div className="flex-1 flex flex-col items-center justify-center py-10 text-center">
              <div className="w-20 h-20 bg-red-600/10 rounded-3xl flex items-center justify-center mb-6 border border-red-600/20">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
              </div>
              <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter">Terminal Locked</h2>
              <p className="text-gray-500 text-sm mb-8 leading-relaxed px-4">
                Registration required to bypass security protocols. Create your account to unlock signals.
              </p>
              <button 
                onClick={handleRegisterClick}
                className="w-full py-4 bg-red-600 text-white font-black rounded-xl shadow-xl active:scale-95 transition-all text-lg mb-4 uppercase tracking-widest"
              >
                Register Account
              </button>
              <p className="text-[10px] text-gray-700 uppercase tracking-widest font-bold italic">99.8% Success Probability Awaiting</p>
            </div>
          ) : !result ? (
            <div className="flex-1 flex flex-col items-center justify-center py-10 text-center">
              <div className="mb-6 opacity-20 grayscale scale-90">
                 <ResponsiveContainer width={300} height={100}>
                   <LineChart data={mockData}>
                     <Line type="monotone" dataKey="value" stroke="#fff" strokeWidth={2} dot={false} />
                   </LineChart>
                 </ResponsiveContainer>
              </div>
              <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter italic">Ready for Analysis</h2>
              <p className="text-gray-500 text-sm mb-8 leading-relaxed px-4">
                Account verified. Initializing Shadow Engine for {pair.name} live candle detection.
              </p>
              <button 
                onClick={startAnalysis}
                className="w-full py-4 bg-[#10b981] text-white font-black rounded-xl shadow-[0_8px_20px_rgba(16,185,129,0.3)] active:scale-95 transition-all text-lg uppercase tracking-widest"
              >
                Launch Analysis
              </button>
            </div>
          ) : (
            <div className="flex-1 flex flex-col">
              <div className="flex-1 h-32 mb-4">
                 <ResponsiveContainer width="100%" height="100%">
                   <LineChart data={mockData}>
                     <YAxis hide domain={['auto', 'auto']} />
                     <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke={result.signal === 'CALL' ? '#10b981' : '#ef4444'} 
                        strokeWidth={4} 
                        dot={false}
                        isAnimationActive={true}
                        animationDuration={2000}
                     />
                   </LineChart>
                 </ResponsiveContainer>
              </div>

              <div className={`p-5 rounded-2xl border ${result.signal === 'CALL' ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'} text-center animate-fade-in`}>
                <div className="mb-2 flex items-center justify-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${result.signal === 'CALL' ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></span>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${result.signal === 'CALL' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                    SURESHOT CONFIRMED: {result.confidence.toFixed(1)}%
                  </span>
                </div>
                
                <h2 className={`text-7xl font-black mb-1 tracking-tighter italic ${result.signal === 'CALL' ? 'text-green-500' : 'text-red-500'}`}>
                  {result.signal}
                </h2>

                <div className="grid grid-cols-2 gap-2 mb-4 mt-2">
                  <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Live Candle</p>
                    <p className="text-sm font-black text-white">{result.candle}</p>
                  </div>
                  <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Live Time</p>
                    <p className="text-sm font-black text-white">{result.time}</p>
                  </div>
                </div>

                <div className="text-gray-400 font-black mb-4 uppercase text-[10px] tracking-widest flex items-center justify-center space-x-2">
                  <span className="bg-white/5 px-2 py-0.5 rounded border border-white/5">EXPIRY: {result.expiry}</span>
                </div>

                <p className="text-gray-500 text-[10px] leading-relaxed bg-black/40 p-2 rounded-lg border border-white/5 mb-6 uppercase font-bold italic">
                  "{result.reasoning}"
                </p>
                
                <a 
                  href={DASHBOARD_LINK} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={`block w-full text-center py-4 text-white font-black rounded-xl shadow-lg active:scale-95 text-lg transition-colors uppercase tracking-widest ${result.signal === 'CALL' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                >
                  Enter Trade
                </a>
              </div>
            </div>
          )}
        </div>

        {result && (
           <div className="mt-8 flex justify-center">
              <button 
                onClick={() => {
                  setResult(null);
                  startAnalysis();
                }}
                className="bg-white/5 text-white px-8 py-3 rounded-full font-black text-[10px] shadow-xl hover:bg-white/10 active:scale-95 transition-all border border-white/10 flex items-center space-x-2 uppercase tracking-widest italic"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M23 4v6h-6"></path>
                  <path d="M1 20v-6h6"></path>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
                <span>Rescan Live Market</span>
              </button>
           </div>
        )}

        <div className="mt-12 text-center">
            <a 
              href={DASHBOARD_LINK} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white/30 text-[10px] uppercase font-black tracking-widest underline underline-offset-4 hover:text-white transition-colors italic"
            >
              Access External Terminal
            </a>
        </div>
      </main>

      <footer className="p-4 text-center text-white/20 text-[9px] font-black uppercase tracking-[0.4em] bg-black">
        {BOT_NAME} • SOFYAN AI CORE • ENCRYPTED
      </footer>
    </div>
  );
};

// --- Main App Component ---
const App: React.FC = () => {
  const [screen, setScreen] = useState<AppScreen>(AppScreen.SPLASH);
  const [selectedPair, setSelectedPair] = useState<CurrencyPair | null>(null);

  const handlePairSelect = (pair: CurrencyPair) => {
    setSelectedPair(pair);
    setScreen(AppScreen.ANALYSIS);
  };

  const handleBackToList = () => {
    setScreen(AppScreen.LIST);
    setSelectedPair(null);
  };

  const renderScreen = () => {
    switch (screen) {
      case AppScreen.SPLASH:
        return <SplashScreen onComplete={() => setScreen(AppScreen.LOGIN)} />;
      case AppScreen.LOGIN:
        return <PasswordScreen onUnlock={() => setScreen(AppScreen.LIST)} />;
      case AppScreen.LIST:
        return <PairList onSelect={handlePairSelect} />;
      case AppScreen.ANALYSIS:
        return selectedPair ? (
          <AnalysisScreen pair={selectedPair} onBack={handleBackToList} />
        ) : null;
      default:
        return <SplashScreen onComplete={() => setScreen(AppScreen.LOGIN)} />;
    }
  };

  return (
    <div className="max-w-md mx-auto shadow-2xl min-h-screen relative overflow-hidden bg-black selection:bg-red-600/30">
      {renderScreen()}
    </div>
  );
};

export default App;
