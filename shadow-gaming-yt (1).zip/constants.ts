
import { CurrencyPair } from './types';

export const CURRENCY_PAIRS: CurrencyPair[] = [
  { id: 'eurusd', name: 'EUR/USD (OTC)', flag1: 'EU', flag2: 'US', isOTC: true },
  { id: 'nzdcad', name: 'NZD/CAD (OTC)', flag1: 'NZ', flag2: 'CA', isOTC: true },
  { id: 'usdars', name: 'USD/ARS (OTC)', flag1: 'US', flag2: 'AR', isOTC: true },
  { id: 'audmxn', name: 'AUD/MXN (OTC)', flag1: 'AU', flag2: 'MX', isOTC: true },
  { id: 'audjpy', name: 'AUD/JPY (OTC)', flag1: 'AU', flag2: 'JP', isOTC: true },
  { id: 'usdbrl', name: 'USD/BRL (OTC)', flag1: 'US', flag2: 'BR', isOTC: true },
  { id: 'eurgbp', name: 'EUR/GBP (OTC)', flag1: 'EU', flag2: 'GB', isOTC: true },
  { id: 'usdtry', name: 'USD/TRY (OTC)', flag1: 'US', flag2: 'TR', isOTC: true },
  { id: 'audchf', name: 'AUD/CHF (OTC)', flag1: 'AU', flag2: 'CH', isOTC: true },
  { id: 'euraud', name: 'EUR/AUD (OTC)', flag1: 'EU', flag2: 'AU', isOTC: true },
  { id: 'eurnzd', name: 'EUR/NZD (OTC)', flag1: 'EU', flag2: 'NZ', isOTC: true },
  { id: 'eursgd', name: 'EUR/SGD (OTC)', flag1: 'EU', flag2: 'SG', isOTC: true },
  { id: 'gbpcad', name: 'GBP/CAD (OTC)', flag1: 'GB', flag2: 'CA', isOTC: true },
  { id: 'gbpchf', name: 'GBP/CHF (OTC)', flag1: 'GB', flag2: 'CH', isOTC: true },
  { id: 'usdbdt', name: 'USD/BDT (OTC)', flag1: 'US', flag2: 'BD', isOTC: true },
  { id: 'usdngn', name: 'USD/NGN (OTC)', flag1: 'US', flag2: 'NG', isOTC: true },
  { id: 'audnzd', name: 'AUD/NZD (OTC)', flag1: 'AU', flag2: 'NZ', isOTC: true },
  { id: 'audusd', name: 'AUD/USD (OTC)', flag1: 'AU', flag2: 'US', isOTC: true },
  { id: 'gbpaud', name: 'GBP/AUD (OTC)', flag1: 'GB', flag2: 'AU', isOTC: true },
  { id: 'gbpjpy', name: 'GBP/JPY (OTC)', flag1: 'GB', flag2: 'JP', isOTC: true },
  { id: 'usdidr', name: 'USD/IDR (OTC)', flag1: 'US', flag2: 'ID', isOTC: true },
  { id: 'usdphp', name: 'USD/PHP (OTC)', flag1: 'US', flag2: 'PH', isOTC: true },
  { id: 'usdpkr', name: 'USD/PKR (OTC)', flag1: 'US', flag2: 'PK', isOTC: true },
  { id: 'usddzd', name: 'USD/DZD (OTC)', flag1: 'US', flag2: 'DZ', isOTC: true },
  { id: 'usdcop', name: 'USD/COP (OTC)', flag1: 'US', flag2: 'CO', isOTC: true },
  { id: 'eurchf', name: 'EUR/CHF (OTC)', flag1: 'EU', flag2: 'CH', isOTC: true },
  { id: 'eurcad', name: 'EUR/CAD (OTC)', flag1: 'EU', flag2: 'CA', isOTC: true },
  { id: 'usdzar', name: 'USD/ZAR (OTC)', flag1: 'US', flag2: 'ZA', isOTC: true },
  { id: 'usdinr', name: 'USD/INR (OTC)', flag1: 'US', flag2: 'IN', isOTC: true },
  { id: 'gbpusd', name: 'GBP/USD (OTC)', flag1: 'GB', flag2: 'US', isOTC: true },
  { id: 'usdjpy', name: 'USD/JPY (OTC)', flag1: 'US', flag2: 'JP', isOTC: true },
  { id: 'cadjpy', name: 'CAD/JPY (OTC)', flag1: 'CA', flag2: 'JP', isOTC: true },
  { id: 'nzdusd', name: 'NZD/USD (OTC)', flag1: 'NZ', flag2: 'US', isOTC: true },
];

export const QUOTEX_LINK = "https://quotex.com.in/";
export const DASHBOARD_LINK = "https://market-qx.trade/en/demo-trade";
