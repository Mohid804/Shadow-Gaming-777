
export interface CurrencyPair {
  id: string;
  name: string;
  flag1: string;
  flag2: string;
  isOTC: boolean;
}

export type SignalType = 'CALL' | 'PUT' | 'WAIT';

export interface AnalysisResult {
  pair: string;
  signal: SignalType;
  confidence: number;
  reasoning: string;
  expiry: string;
  candle: string;
  time: string;
}

export enum AppScreen {
  SPLASH,
  LOGIN,
  LIST,
  ANALYSIS
}
